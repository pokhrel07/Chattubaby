import React, { useState } from "react";

export default function App() {
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState("");

  async function send() {
    const res = await fetch("http://localhost:3001/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message: text })
    });

    const data = await res.json();
    setMessages([...messages, { user: text, bot: data.reply }]);
    setText("");
  }

  return (
    <div>
      <h2>ChatGPT Simple Clone</h2>
      <div>
        {messages.map((m, i) => (
          <p key={i}><b>You:</b> {m.user} <br /><b>Bot:</b> {m.bot}</p>
        ))}
      </div>
      <input value={text} onChange={(e) => setText(e.target.value)} />
      <button onClick={send}>Send</button>
    </div>
  );
}
